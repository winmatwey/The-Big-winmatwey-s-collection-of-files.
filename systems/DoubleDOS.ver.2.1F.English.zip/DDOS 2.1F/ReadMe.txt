DoubleDOS 2.1F (1984)
Released in 1984 by SoftLogic Solutions, Inc.
For DOS 2.0 and 2.1.

DoubleDOS is a simple and easy to use multitasking tool for DOS. It
can preemptively run up to two DOS programs at a time. Its main
advantage is that it requires very little RAM overhead compared to
other multitasking or task switching environments. Because DOS
programs can and usually do bypass OS calls, many programs must be
"patched" in order to work.

DoubleDOS is a minimalist program, but if you only needed to do two
things at once, then this would have been a good choice. Reportedly,
the first version may have worked with DOS 1.x.

This version is very picky about what version of DOS it is running
on. It only supports IBM PC-DOS 2.0 and IBM PC-DOS 2.1.

Important: This version has an unprotect applied to it. The software
is normally copy protected.

Wanted: Kryoflux/SCP/Transcopy dump of the original media.

Archive includes one 5.25" 160k floppy disk image.
